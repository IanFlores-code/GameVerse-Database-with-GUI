﻿"""Database access for GameVerse.

* One connection is opened and reused for the whole session (reconnects if it drops).
* Every query is parameterized (%s placeholders) - never string-built from user input.
* Errors come back as short, readable messages instead of stack traces.
"""
import psycopg2
import psycopg2.extras
from psycopg2 import errorcodes

try:
    from config.config import DB_CONFIG          # your local settings (not committed)
except ImportError:                              # fall back to env vars / defaults
    from config.config_template import DB_CONFIG

# Assignment 3 constraint name -> message shown to the user
CONSTRAINT_MESSAGES = {
    "chk_wallet_balance_min": "This would take the wallet below its minimum balance.",
    "chk_wallet_bonusrate": "Bonus rate must be between 0 and 5.",
    "chk_wallet_type": "Wallet type must be Standard, Vault or Guild.",
    "chk_txn_amount_nonzero": "Transaction amount cannot be zero.",
    "chk_txn_sign_matches_type": "The amount sign does not match the transaction type.",
    "chk_player_min_age": "Players must be at least 13 years old to register.",
    "chk_player_reg_not_future": "Registration date cannot be in the future.",
    "players_email_key": "That email address is already registered.",
    "uq_review_player_wallet": "You have already reviewed this wallet. Only one review per wallet is allowed.",
    "walletreviews_rating_check": "Rating must be between 1 and 5.",
    "chk_review_date_not_future": "Review date cannot be in the future.",
    "uq_one_owner_per_wallet": "This wallet already has an Owner.",
    "walletholders_pkey": "That player already holds this wallet.",
    "fk_holder_player": "That player does not exist.",
    "fk_holder_wallet": "That wallet does not exist.",
    "wallets_hubid_fkey": "That hub does not exist.",
    "gametransactions_walletid_fkey": "That wallet does not exist.",
    "walletreviews_walletid_fkey": "That wallet does not exist.",
    "walletreviews_playerid_fkey": "That player does not exist.",
}


def friendly_error(err: Exception) -> str:
    """Turn a psycopg2 error into a sentence a user can read."""
    if isinstance(err, psycopg2.OperationalError):
        return ("Database connection failed. Check that PostgreSQL is running and that "
                "config/config.py has the right host, port, database name and password.")
    diag = getattr(err, "diag", None)
    constraint = getattr(diag, "constraint_name", None) if diag else None
    if constraint in CONSTRAINT_MESSAGES:
        return CONSTRAINT_MESSAGES[constraint]
    if getattr(err, "pgcode", None) == errorcodes.RAISE_EXCEPTION and diag and diag.message_primary:
        return diag.message_primary          # messages from our own PL/pgSQL functions
    if diag and diag.message_primary:
        return diag.message_primary
    return str(err).split("\n")[0]


class DatabaseManager:
    _conn = None

    @classmethod
    def get_connection(cls):
        """Return the shared connection, opening it (again) if needed."""
        if cls._conn is None or cls._conn.closed:
            cls._conn = psycopg2.connect(**DB_CONFIG, connect_timeout=5,
                                         options="-c search_path=gameverse,public")
        return cls._conn

    @classmethod
    def close(cls):
        if cls._conn is not None and not cls._conn.closed:
            cls._conn.close()
        cls._conn = None

    @classmethod
    def test_connection(cls):
        """Connect and check that the six GameVerse tables exist."""
        try:
            ok, rows = cls.execute_query(
                "SELECT COUNT(*) FROM information_schema.tables "
                "WHERE table_schema = 'gameverse' AND table_name = ANY(%s);",
                (["gaminghubs", "wallets", "players", "gametransactions",
                  "walletholders", "walletreviews"],), fetch=True)
        except psycopg2.Error as e:
            return False, friendly_error(e)
        if not ok:
            return False, rows
        if rows[0][0] < 6:
            return False, ("Connected, but the gameverse schema is missing tables. "
                           "Run gameverse_setup.sql on this database first.")
        return True, "Connected to GameVerse database successfully."

    @classmethod
    def execute_query(cls, query, params=None, fetch=False, as_dict=False):
        """Run one statement in its own transaction.

        Returns (True, rows) on success - rows is a list of tuples, or of dicts when
        as_dict=True, or None when fetch=False - and (False, message) on failure.
        """
        try:
            conn = cls.get_connection()
        except psycopg2.Error as e:
            return False, friendly_error(e)
        factory = psycopg2.extras.RealDictCursor if as_dict else None
        try:
            with conn:                                   # commit, or roll back on error
                with conn.cursor(cursor_factory=factory) as cur:
                    cur.execute(query, params or ())
                    if fetch:
                        rows = cur.fetchall()
                        return True, [dict(r) for r in rows] if as_dict else rows
                    return True, None
        except psycopg2.InterfaceError:
            cls.close()                                  # connection dropped; next call reconnects
            return False, "Lost the database connection. Please try again."
        except psycopg2.Error as e:
            return False, friendly_error(e)
