GAMEVERSE WALLET MANAGER - HOW TO RUN

The startup guide is now README.md in the repository root (two folders up).
Short version, from the repository root:

  1. pgAdmin: create database GameVerse, run gameverse_setup.sql (F5)
  2. py -m pip install -r requirements.txt
  3. copy config\config_template.py config\config.py   (add your password)
  4. $env:PYTHONPATH=".;GameVerse_frontend\gameverse-app"; python GameVerse_frontend\gameverse-app\main.py
  5. Log in:  admin / Admin@123    or   alex.chen@gameverse.com / player123
