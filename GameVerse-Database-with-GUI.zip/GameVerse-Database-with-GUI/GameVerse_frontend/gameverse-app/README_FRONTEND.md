# GameVerse Wallet Manager: Frontend (Tkinter GUI)

How to install and run the whole project: see **README.md in the repository root**.

This folder holds the Python 3.10+ / Tkinter GUI with role-based login
(Admin / Player). It covers every module in the assignment guide plus
Optional Task 4 (analytics chart, bonus projection, balance notifications).

## Layout

```
main.py                     entry point; adds the repo root to the import path
gui/
  api.py                    the ONLY bridge between screens and the backend
                            (calls services.GameVerseService, raises AppError)
  app.py                    window: connection test, login <-> shell switching
  theme.py                  colors, fonts, ttk styles
  widgets.py                DataTable, FormDialog, DetailsDialog, TableDialog, Segmented
  validators.py             input-format parsing (money, dates, email...)
  session.py                who is logged in (role, playerid)
  views/                    one file per screen: login, overview, hubs, wallets,
                            transactions, players, profile, reviews, analytics
tests/test_gui_validators.py
docs/                       screenshots and the frontend documentation (.docx)
```

Layers: **screens -> gui/api.py -> services/gameverse_service.py ->
db/db_manager.py -> PostgreSQL (stored functions + triggers)**. No screen
builds SQL, and every query is parameterized.

## Design rules the GUI follows

- Business rules stay in the database. Transactions go through
  `performTransaction()` / `transferFunds()`; their messages are shown word for
  word (e.g. `Insufficient funds. Spendable balance: 2,400.00 (balance 2,500.00, minimum 100.00)`).
  The live funds hint calls `checkSufficientBalance()`.
- No stack traces: the service returns `(False, message)`, `api.py` turns it
  into `AppError`, and the screen shows the message in a dialog or inside the form.
- Role-based menus: admins see Players and admin actions; players see only
  their own wallets. Access is also checked in the backend.
- Deactivate instead of delete for hubs, wallets and players.
