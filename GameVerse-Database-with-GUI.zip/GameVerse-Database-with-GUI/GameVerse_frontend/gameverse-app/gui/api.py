"""Bridge between the GameVerse GUI and the backend (services.GameVerseService).

Every screen calls functions here and nothing else from the backend. Each
function returns plain Python data (dicts / lists of dicts / ints / bools) and
raises AppError(message) when the backend reports a problem, so the GUI can
show the message instead of a stack trace.
"""
from datetime import date
from decimal import Decimal

from db.db_manager import DatabaseManager
from services.gameverse_service import GameVerseService as S

__all__ = ["AppError"]

TRANSACTION_TYPES = ["TopUp", "Cashout", "Purchase", "Transfer"]
PAYMENT_METHODS = ["App", "Kiosk", "Hub Counter", "Bank Transfer"]
WALLET_TYPES = ["Standard", "Vault", "Guild"]


class AppError(Exception):
    """User-facing error raised when a backend or database operation fails."""


def _ok(result):
    """Unwrap a (success, payload) pair from the service layer."""
    success, payload = result
    if not success:
        raise AppError(str(payload) if payload else "Operation failed.")
    return payload


def _check_holder(playerid: int | None, walletid: int, roles=("Owner", "Co-Owner", "Member")):
    if playerid is not None:          # None = admin, no restriction
        _ok(S.verify_wallet_ownership(playerid, walletid, required_roles=roles))


# ---------------------------------------------------------------- auth
def test_connection() -> None:
    _ok(DatabaseManager.test_connection())


def login_admin(username: str, password: str) -> dict:
    a = _ok(S.authenticate_admin(username.strip(), password))
    return {"role": "admin", "username": a["username"], "display_name": a["username"]}


def login_player(email: str, password: str) -> dict:
    p = _ok(S.authenticate_player(email.strip(), password))
    return {"role": "player", "playerid": p["playerid"], "email": p["email"],
            "display_name": p["name"]}


def register_player(firstname: str, lastname: str, email: str, phone: str,
                    dateofbirth: date, password: str) -> int:
    return int(_ok(S.register_player(firstname, lastname, email, phone, dateofbirth, password)))


# ---------------------------------------------------------------- hubs
def list_hubs(active_only: bool = True) -> list[dict]:
    return _ok(S.get_gaming_hubs(active_only))


def search_hubs(term: str, active_only: bool = True) -> list[dict]:
    return _ok(S.search_hubs(term.strip(), active_only))


def get_hub_details(hubid: int) -> dict:
    return _ok(S.get_hub_details(hubid))


def add_hub(hubname: str, location: str) -> int:
    return int(_ok(S.add_hub(hubname, location)))


def update_hub(hubid: int, hubname: str, location: str) -> None:
    _ok(S.update_hub(hubid, hubname, location))


def set_hub_active(hubid: int, active: bool) -> None:
    _ok(S.set_hub_active(hubid, active))


def hub_summary_report() -> list[dict]:
    return _ok(S.hub_summary_report())


# ---------------------------------------------------------------- wallets
def list_player_wallets(playerid: int) -> list[dict]:
    return _ok(S.get_player_wallets(playerid))


def list_all_wallets() -> list[dict]:
    return _ok(S.get_all_wallets())


def get_wallet(walletid: int, playerid: int | None = None) -> dict:
    _check_holder(playerid, walletid)
    return _ok(S.get_wallet(walletid))


def get_wallet_summary(walletid: int, playerid: int | None = None) -> dict:
    """Result of getWalletSummary(walletID)."""
    _check_holder(playerid, walletid)
    return _ok(S.get_wallet_summary(walletid))


def check_sufficient_balance(walletid: int, amount: Decimal) -> bool:
    return bool(_ok(S.check_sufficient_balance(walletid, amount)))


def low_balance_alerts(threshold: Decimal, playerid: int | None = None) -> list[dict]:
    rows = _ok(S.get_low_balance_alerts(threshold))
    if playerid is not None:
        mine = {w["walletid"] for w in list_player_wallets(playerid)}
        rows = [r for r in rows if r["walletid"] in mine]
    return rows


def open_wallet(playerid: int, wallettype: str, hubid: int, balance: Decimal,
                minimumbalance: Decimal, bonusrate: Decimal, description: str) -> int:
    return int(_ok(S.open_wallet(playerid, wallettype, hubid, balance, minimumbalance,
                                 bonusrate, description)))


def update_wallet(walletid: int, bonusrate: Decimal, description: str) -> None:
    _ok(S.update_wallet(walletid, bonusrate, description))


def set_wallet_active(walletid: int, active: bool) -> None:
    _ok(S.set_wallet_active(walletid, active))


def wallet_inventory() -> list[dict]:
    return _ok(S.wallet_inventory())


# ---------------------------------------------------------------- players
def list_players() -> list[dict]:
    return _ok(S.get_players())


def get_player(playerid: int) -> dict:
    return _ok(S.get_player_profile(playerid))


def update_player_contact(playerid: int, email: str, phone: str) -> None:
    _ok(S.update_player_contact(playerid, email, phone))


def set_player_active(playerid: int, active: bool) -> None:
    _ok(S.set_player_active(playerid, active))


def player_memberships(playerid: int) -> list[dict]:
    return list_player_wallets(playerid)


def player_transactions(playerid: int) -> list[dict]:
    return _ok(S.get_player_transactions(playerid))


def player_reviews(playerid: int) -> list[dict]:
    return _ok(S.get_player_reviews(playerid))


# ---------------------------------------------------------------- transactions
def perform_transaction(walletid: int, amount: Decimal, transactiontype: str,
                        paymentmethod: str, recipient: str,
                        playerid: int | None = None) -> int:
    """TopUp / Cashout / Purchase via performTransaction(). amount is POSITIVE."""
    _check_holder(playerid, walletid, roles=("Owner", "Co-Owner"))
    return int(_ok(S.record_transaction(walletid, amount, transactiontype,
                                        recipient=recipient, payment_method=paymentmethod)))


def transfer_funds(from_walletid: int, to_walletid: int, amount: Decimal,
                   paymentmethod: str, playerid: int | None = None) -> int:
    """Calls transferFunds(). Returns the sending transaction id."""
    _check_holder(playerid, from_walletid, roles=("Owner", "Co-Owner"))
    return int(_ok(S.transfer_funds(from_walletid, to_walletid, amount, paymentmethod)))


def wallet_transactions(walletid: int, date_from: date | None = None,
                        date_to: date | None = None, txn_type: str | None = None,
                        playerid: int | None = None) -> list[dict]:
    _check_holder(playerid, walletid)
    return _ok(S.get_wallet_transactions(walletid, date_from, date_to, txn_type))


def totals_by_payment_method(walletid: int | None = None,
                             playerid: int | None = None) -> list[dict]:
    if walletid is not None:
        _check_holder(playerid, walletid)
    return _ok(S.totals_by_payment_method(walletid, playerid))


def reverse_transaction(transactionid: int) -> list[int]:
    """Admin only. Restores the balance. Returns the ids of the reversal rows."""
    return _ok(S.reverse_transaction(transactionid))


# ---------------------------------------------------------------- reviews
def add_review(playerid: int, walletid: int, rating: int, reviewtext: str) -> int:
    _check_holder(playerid, walletid)
    return int(_ok(S.submit_wallet_review(playerid, walletid, rating, comment=reviewtext)))


def list_reviews(walletid: int | None = None) -> list[dict]:
    return _ok(S.get_reviews(walletid))


def set_review_verified(reviewid: int, verified: bool) -> None:
    _ok(S.set_review_verified(reviewid, verified))


def avg_rating_by_wallet_type() -> list[dict]:
    return _ok(S.get_average_rating_per_wallet_type())


# ---------------------------------------------------------------- analytics (bonus)
def monthly_flows(walletid: int | None = None, playerid: int | None = None) -> list[dict]:
    """-> rows: month ('YYYY-MM'), topups, cashouts, purchases."""
    if walletid is not None:
        _check_holder(playerid, walletid)
    return _ok(S.monthly_flows(walletid, playerid))
