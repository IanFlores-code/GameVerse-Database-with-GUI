"""GameVerse Wallet Manager - entry point.

    py GameVerse_frontend/gameverse-app/main.py        (from the repo root)
    py main.py                                          (from this folder)

The backend packages (config/, db/, services/) live in the repository root, so
the root is added to the import path here - no PYTHONPATH setup needed.
"""
import sys
from pathlib import Path

APP_DIR = Path(__file__).resolve().parent            # .../GameVerse_frontend/gameverse-app
REPO_ROOT = APP_DIR.parents[1]                        # repository root
for p in (str(APP_DIR), str(REPO_ROOT)):
    if p not in sys.path:
        sys.path.insert(0, p)

from gui.app import GameVerseApp  # noqa: E402  (import after the path setup)


def main() -> None:
    app = GameVerseApp()
    app.after(0, app.start)
    app.mainloop()


if __name__ == "__main__":
    main()
