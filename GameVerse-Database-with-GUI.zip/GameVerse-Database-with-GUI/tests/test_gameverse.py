"""Business-rule tests for the GameVerse service layer and database functions.

Run from the repository root:   py -m pytest
Needs the database from gameverse_setup.sql and a working config/config.py.

Each test undoes its own balance changes (or only checks relative changes),
so the suite can be run any number of times on the same database.
"""
from decimal import Decimal

import pytest

from db.db_manager import DatabaseManager
from services.gameverse_service import GameVerseService as S

ALEX = 3001          # Owner of 2001 and 2002
CARLOS = 3003        # Member of 2012
W_STANDARD = 2001
W_VAULT = 2002
W_OTHER = 2005


def balance(wallet_id):
    ok, w = S.get_wallet(wallet_id)
    assert ok, w
    return w["balance"]


def spendable(wallet_id):
    ok, w = S.get_wallet(wallet_id)
    assert ok, w
    return w["balance"] - w["minimumbalance"]


@pytest.fixture(scope="session", autouse=True)
def database_ready():
    ok, msg = DatabaseManager.test_connection()
    if not ok:
        pytest.skip(f"Database not available: {msg}")


# ----------------------------------------------------------------- balance validation
def test_cashout_above_spendable_is_rejected_and_balance_unchanged():
    before = balance(W_STANDARD)
    too_much = spendable(W_STANDARD) + Decimal("1.00")
    ok, msg = S.record_transaction(W_STANDARD, too_much, "Cashout", "Self", "Kiosk")
    assert ok is False
    assert msg.startswith("Insufficient funds. Spendable balance:")
    assert balance(W_STANDARD) == before


def test_check_sufficient_balance_respects_minimum():
    room = spendable(W_STANDARD)
    assert S.check_sufficient_balance(W_STANDARD, room) == (True, True)
    assert S.check_sufficient_balance(W_STANDARD, room + Decimal("0.01")) == (True, False)


def test_purchase_above_spendable_is_rejected():
    ok, msg = S.record_transaction(W_STANDARD, spendable(W_STANDARD) + 1, "Purchase", "Store", "App")
    assert ok is False and "Insufficient funds" in msg


# ----------------------------------------------------------------- automatic balance update
def test_topup_then_cashout_updates_balance_through_trigger():
    before = balance(W_STANDARD)
    ok, txn = S.record_transaction(W_STANDARD, Decimal("500.00"), "TopUp", "Self", "App")
    assert ok, txn
    assert balance(W_STANDARD) == before + Decimal("500.00")
    ok, txn = S.record_transaction(W_STANDARD, Decimal("500.00"), "Cashout", "Self", "Kiosk")
    assert ok, txn
    assert balance(W_STANDARD) == before


def test_transfer_moves_exact_amount_both_ways():
    a, b = balance(W_VAULT), balance(W_OTHER)
    ok, txn = S.transfer_funds(W_VAULT, W_OTHER, Decimal("100.00"), "App")
    assert ok, txn
    assert balance(W_VAULT) == a - Decimal("100.00")
    assert balance(W_OTHER) == b + Decimal("100.00")
    ok, txn = S.transfer_funds(W_OTHER, W_VAULT, Decimal("100.00"), "App")
    assert ok, txn
    assert (balance(W_VAULT), balance(W_OTHER)) == (a, b)


def test_transfer_to_same_wallet_is_rejected():
    ok, msg = S.transfer_funds(W_VAULT, W_VAULT, Decimal("1.00"))
    assert ok is False


def test_reversal_restores_balance():
    before = balance(W_STANDARD)
    ok, txn = S.record_transaction(W_STANDARD, Decimal("25.00"), "TopUp", "Self", "App")
    assert ok, txn
    ok, ids = S.reverse_transaction(txn)
    assert ok, ids
    assert balance(W_STANDARD) == before
    ok, msg = S.reverse_transaction(txn)
    assert ok is False and "already been reversed" in msg


def test_wallet_summary_function():
    ok, s = S.get_wallet_summary(W_STANDARD)
    assert ok, s
    assert s["balance"] == balance(W_STANDARD)
    assert s["transaction_count"] > 0


def test_inactive_wallet_rejects_transactions():
    S.set_wallet_active(2009, False)
    try:
        ok, msg = S.record_transaction(2009, Decimal("10.00"), "TopUp", "Self", "App")
        assert ok is False and "inactive" in msg
    finally:
        S.set_wallet_active(2009, True)


# ----------------------------------------------------------------- authentication and roles
def test_player_login_checks_password():
    ok, res = S.authenticate_player("alex.chen@gameverse.com", "player123")
    assert ok is True and res["playerid"] == ALEX
    ok, _ = S.authenticate_player("alex.chen@gameverse.com", "wrong-password")
    assert ok is False


def test_admin_login_checks_password():
    assert S.authenticate_admin("admin", "Admin@123")[0] is True
    assert S.authenticate_admin("admin", "admin")[0] is False


def test_member_cannot_transact_but_owner_can():
    assert S.verify_wallet_ownership(ALEX, W_STANDARD)[0] is True
    ok, msg = S.verify_wallet_ownership(CARLOS, 2012)
    assert ok is False and "Member" in msg


# ----------------------------------------------------------------- constraints surface as messages
def test_duplicate_review_is_rejected():
    ok, msg = S.submit_wallet_review(ALEX, W_STANDARD, 5, "Second review of the same wallet")
    assert ok is False and "already reviewed" in msg


def test_duplicate_email_is_rejected():
    ok, msg = S.update_player_contact(ALEX, "bianca.ruiz@gameverse.com", None)
    assert ok is False and "already registered" in msg


def test_hub_with_active_wallets_cannot_be_deactivated():
    ok, msg = S.set_hub_active(1, False)
    assert ok is False and "active wallet" in msg


def test_bonus_projection():
    ok, res = S.project_wallet_bonus(W_STANDARD)
    assert ok is True and "12_months" in res


def test_get_gaming_hubs():
    ok, hubs = S.get_gaming_hubs()
    assert ok is True and len(hubs) >= 5
