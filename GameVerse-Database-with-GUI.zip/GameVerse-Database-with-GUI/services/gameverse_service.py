﻿"""GameVerse service layer.

Every method returns (success, result): result is the data on success, or a
user-readable message on failure.

Business rules live in the database (gameverse_setup.sql):
  * performTransaction / transferFunds  - validate amounts and balances, insert rows
  * checkSufficientBalance / getWalletSummary / getLowBalanceAlerts
  * triggers - update wallet balances after each insert and reject inactive wallets
This module never changes a balance itself; it only calls those functions and
does access checks (who may see or transact on a wallet).
"""
from db.db_manager import DatabaseManager

TRANSACTABLE_ROLES = ("Owner", "Co-Owner")
ALL_ROLES = ("Owner", "Co-Owner", "Member")

_q = DatabaseManager.execute_query


def _rows(query, params=()):
    return _q(query, params, fetch=True, as_dict=True)


def _one(query, params=(), not_found="Not found."):
    ok, rows = _rows(query, params)
    if not ok:
        return False, rows
    return (True, rows[0]) if rows else (False, not_found)


class GameVerseService:
    # ================================================================ auth
    @staticmethod
    def authenticate_player(email, password):
        """Checks the bcrypt hash stored in players.passwordhash."""
        ok, row = _one(
            "SELECT playerid, firstname, lastname, email, isactive FROM players "
            "WHERE lower(email) = lower(%s) AND passwordhash = crypt(%s, passwordhash);",
            (email, password), not_found="Invalid email or password.")
        if not ok:
            return False, row
        if not row["isactive"]:
            return False, "Account is deactivated. Contact an administrator."
        return True, {"role": "Player", "playerid": row["playerid"], "email": row["email"],
                      "name": f"{row['firstname']} {row['lastname']}"}

    @staticmethod
    def authenticate_admin(username, password):
        ok, row = _one(
            "SELECT adminid, username FROM admins "
            "WHERE username = %s AND passwordhash = crypt(%s, passwordhash);",
            (username, password), not_found="Invalid admin username or password.")
        if not ok:
            return False, row
        return True, {"role": "Admin", "adminid": row["adminid"], "username": row["username"]}

    @staticmethod
    def register_player(firstname, lastname, email, phone, date_of_birth, password):
        """New player; the password is stored only as a bcrypt hash.
        Age >= 13 and unique email are enforced by the Assignment 3 constraints."""
        ok, row = _one(
            "INSERT INTO players (firstname, lastname, email, phone, dateofbirth, "
            "registrationdate, isactive, passwordhash) "
            "VALUES (%s, %s, %s, %s, %s, CURRENT_DATE, TRUE, crypt(%s, gen_salt('bf'))) "
            "RETURNING playerid;",
            (firstname, lastname, email, phone or None, date_of_birth, password))
        return (True, row["playerid"]) if ok else (False, row)

    @staticmethod
    def verify_wallet_ownership(player_id, wallet_id, required_roles=TRANSACTABLE_ROLES):
        """Members can view but not transact; Owners/Co-Owners can transact."""
        ok, row = _one("SELECT holderrole FROM walletholders WHERE playerid = %s AND walletid = %s;",
                       (player_id, wallet_id), not_found=f"You do not hold wallet {wallet_id}.")
        if not ok:
            return False, row
        role = row["holderrole"]
        if role in required_roles:
            return True, role
        return False, (f"Your role on wallet {wallet_id} is '{role}'. "
                       "Only an Owner or Co-Owner can make transactions.")

    # ================================================================ stored functions
    @staticmethod
    def get_wallet_summary(wallet_id):
        """getWalletSummary(walletID)"""
        return _one("SELECT * FROM getWalletSummary(%s);", (wallet_id,),
                    not_found=f"Wallet {wallet_id} does not exist.")

    @staticmethod
    def check_sufficient_balance(wallet_id, required_amount):
        """checkSufficientBalance(walletID, amount): True if balance - amount >= minimum."""
        ok, row = _one("SELECT checkSufficientBalance(%s, %s) AS ok;", (wallet_id, required_amount))
        return (True, bool(row["ok"])) if ok else (False, row)

    @staticmethod
    def get_low_balance_alerts(threshold):
        """getLowBalanceAlerts(threshold)"""
        return _rows("SELECT * FROM getLowBalanceAlerts(%s);", (threshold,))

    @staticmethod
    def record_transaction(wallet_id, amount, transaction_type, recipient=None, payment_method=None):
        """TopUp / Cashout / Purchase through performTransaction().
        amount is the POSITIVE amount; the function applies the sign, checks the
        minimum balance, and the trigger updates the wallet balance."""
        ok, row = _one("SELECT performTransaction(%s, %s, %s, %s, %s) AS id;",
                       (wallet_id, abs(amount), transaction_type, payment_method, recipient))
        return (True, row["id"]) if ok else (False, row)

    @staticmethod
    def transfer_funds(source_wallet_id, target_wallet_id, amount, payment_method="App"):
        """transferFunds(): both legs are inserted atomically inside the function."""
        ok, row = _one("SELECT transferFunds(%s, %s, %s, %s) AS id;",
                       (source_wallet_id, target_wallet_id, abs(amount), payment_method))
        return (True, row["id"]) if ok else (False, row)

    # ================================================================ hubs
    @staticmethod
    def get_gaming_hubs(active_only=False):
        return _rows("SELECT hubid, hubname, location, isactive FROM gaminghubs "
                     "WHERE (%s = FALSE OR isactive) ORDER BY hubid;", (active_only,))

    @staticmethod
    def search_hubs(term, active_only=True):
        like = f"%{term}%"
        return _rows("SELECT hubid, hubname, location, isactive FROM gaminghubs "
                     "WHERE (hubname ILIKE %s OR location ILIKE %s) AND (%s = FALSE OR isactive) "
                     "ORDER BY hubid;", (like, like, active_only))

    @staticmethod
    def add_hub(hub_name, location):
        ok, row = _one("INSERT INTO gaminghubs (hubname, location, isactive) VALUES (%s, %s, TRUE) "
                       "RETURNING hubid;", (hub_name, location))
        return (True, row["hubid"]) if ok else (False, row)

    @staticmethod
    def update_hub(hub_id, hub_name, location):
        ok, row = _one("UPDATE gaminghubs SET hubname = %s, location = %s WHERE hubid = %s "
                       "RETURNING hubid;", (hub_name, location, hub_id), not_found="Hub not found.")
        return (True, row["hubid"]) if ok else (False, row)

    @staticmethod
    def set_hub_active(hub_id, active):
        if not active:
            ok, row = _one("SELECT COUNT(*) AS n FROM wallets WHERE hubid = %s AND isactive;", (hub_id,))
            if not ok:
                return False, row
            if row["n"]:
                return False, (f"Hub {hub_id} still has {row['n']} active wallet(s). "
                               "Deactivate or move them before deactivating the hub.")
        ok, row = _one("UPDATE gaminghubs SET isactive = %s WHERE hubid = %s RETURNING hubid;",
                       (bool(active), hub_id), not_found="Hub not found.")
        return (True, row["hubid"]) if ok else (False, row)

    _HUB_STATS = """
        SELECT h.hubid, h.hubname, h.location, h.isactive,
               COUNT(w.walletid) AS wallet_count,
               COUNT(w.walletid) FILTER (WHERE w.isactive) AS active_wallets,
               COALESCE(SUM(w.balance), 0) AS total_balance,
               ROUND(AVG(w.bonusrate), 2) AS avg_bonus_rate
        FROM gaminghubs h LEFT JOIN wallets w ON w.hubid = h.hubid
    """

    @staticmethod
    def get_hub_details(hub_id):
        return _one(GameVerseService._HUB_STATS + " WHERE h.hubid = %s GROUP BY h.hubid;",
                    (hub_id,), not_found="Hub not found.")

    @staticmethod
    def hub_summary_report():
        return _rows(GameVerseService._HUB_STATS + " GROUP BY h.hubid ORDER BY h.hubid;")

    # ================================================================ wallets
    _WALLET_COLS = ("w.walletid, w.wallettype, w.hubid, h.hubname, w.balance, w.bonusrate, "
                    "w.walletdescription, w.opendate, w.minimumbalance, w.isactive")

    @staticmethod
    def get_player_wallets(player_id):
        return _rows(f"SELECT {GameVerseService._WALLET_COLS}, wh.holderrole "
                     "FROM walletholders wh JOIN wallets w ON w.walletid = wh.walletid "
                     "JOIN gaminghubs h ON h.hubid = w.hubid "
                     "WHERE wh.playerid = %s ORDER BY w.walletid;", (player_id,))

    @staticmethod
    def get_all_wallets():
        return _rows(f"SELECT {GameVerseService._WALLET_COLS}, "
                     "  (SELECT p.firstname || ' ' || p.lastname FROM walletholders wh "
                     "   JOIN players p ON p.playerid = wh.playerid "
                     "   WHERE wh.walletid = w.walletid AND wh.holderrole = 'Owner') AS owner "
                     "FROM wallets w JOIN gaminghubs h ON h.hubid = w.hubid ORDER BY w.walletid;")

    @staticmethod
    def get_wallet(wallet_id):
        return _one(f"SELECT {GameVerseService._WALLET_COLS} FROM wallets w "
                    "JOIN gaminghubs h ON h.hubid = w.hubid WHERE w.walletid = %s;",
                    (wallet_id,), not_found=f"Wallet {wallet_id} does not exist.")

    @staticmethod
    def open_wallet(player_id, wallet_type, hub_id, balance, minimum_balance, bonus_rate, description):
        """Creates the Wallets row and the Owner WalletHolders row in ONE transaction."""
        if balance < minimum_balance:
            return False, "Initial balance must be at least the minimum balance."
        try:
            conn = DatabaseManager.get_connection()
            with conn:
                with conn.cursor() as cur:
                    cur.execute("SELECT isactive FROM players WHERE playerid = %s;", (player_id,))
                    p = cur.fetchone()
                    if not p or not p[0]:
                        conn.rollback()
                        return False, "Choose an active player."
                    cur.execute("SELECT isactive FROM gaminghubs WHERE hubid = %s;", (hub_id,))
                    h = cur.fetchone()
                    if not h or not h[0]:
                        conn.rollback()
                        return False, "Choose an active hub."
                    cur.execute(
                        "INSERT INTO wallets (wallettype, hubid, balance, bonusrate, walletdescription, "
                        "opendate, minimumbalance, isactive) "
                        "VALUES (%s, %s, %s, %s, %s, CURRENT_DATE, %s, TRUE) RETURNING walletid;",
                        (wallet_type, hub_id, balance, bonus_rate, description, minimum_balance))
                    wallet_id = cur.fetchone()[0]
                    cur.execute(
                        "INSERT INTO walletholders (walletid, playerid, holderrole, joindate, depositamount) "
                        "VALUES (%s, %s, 'Owner', CURRENT_DATE, %s);", (wallet_id, player_id, balance))
            return True, wallet_id
        except Exception as e:                       # psycopg2 errors -> readable text
            from db.db_manager import friendly_error
            return False, friendly_error(e)

    @staticmethod
    def update_wallet(wallet_id, bonus_rate, description):
        ok, row = _one("UPDATE wallets SET bonusrate = %s, walletdescription = %s WHERE walletid = %s "
                       "RETURNING walletid;", (bonus_rate, description, wallet_id),
                       not_found="Wallet not found.")
        return (True, row["walletid"]) if ok else (False, row)

    @staticmethod
    def set_wallet_active(wallet_id, active):
        ok, row = _one("UPDATE wallets SET isactive = %s WHERE walletid = %s RETURNING walletid;",
                       (bool(active), wallet_id), not_found="Wallet not found.")
        return (True, row["walletid"]) if ok else (False, row)

    @staticmethod
    def wallet_inventory():
        return _rows("SELECT wallettype, COUNT(*) AS wallet_count, "
                     "COUNT(*) FILTER (WHERE isactive) AS active_count, "
                     "COALESCE(SUM(balance), 0) AS total_balance, ROUND(AVG(balance), 2) AS avg_balance "
                     "FROM wallets GROUP BY wallettype ORDER BY wallettype;")

    @staticmethod
    def project_wallet_bonus(wallet_id):
        """Bonus projection (Optional Task 4): annual rate compounded monthly."""
        ok, row = _one("SELECT balance, bonusrate FROM wallets WHERE walletid = %s;", (wallet_id,),
                       not_found="Wallet not found.")
        if not ok:
            return False, row
        balance, rate = float(row["balance"]), float(row["bonusrate"]) / 100 / 12
        return True, {f"{m}_month{'s' if m > 1 else ''}": round(balance * (1 + rate) ** m, 2)
                      for m in (1, 6, 12)}

    # ================================================================ players
    _PLAYER_COLS = "playerid, firstname, lastname, email, phone, dateofbirth, registrationdate, isactive"

    @staticmethod
    def get_players():
        return _rows(f"SELECT {GameVerseService._PLAYER_COLS} FROM players ORDER BY playerid;")

    @staticmethod
    def get_player_profile(player_id):
        return _one(f"SELECT {GameVerseService._PLAYER_COLS} FROM players WHERE playerid = %s;",
                    (player_id,), not_found="Player not found.")

    @staticmethod
    def update_player_contact(player_id, email, phone):
        ok, row = _one("UPDATE players SET email = %s, phone = %s WHERE playerid = %s RETURNING playerid;",
                       (email, phone or None, player_id), not_found="Player not found.")
        return (True, row["playerid"]) if ok else (False, row)

    @staticmethod
    def set_player_active(player_id, active):
        ok, row = _one("UPDATE players SET isactive = %s WHERE playerid = %s RETURNING playerid;",
                       (bool(active), player_id), not_found="Player not found.")
        return (True, row["playerid"]) if ok else (False, row)

    @staticmethod
    def get_player_transactions(player_id):
        return _rows("SELECT t.transactionid, t.walletid, t.transactiondate, t.amount, t.transactiontype, "
                     "t.recipient, t.paymentmethod, t.linkedtxnid "
                     "FROM gametransactions t JOIN walletholders wh ON wh.walletid = t.walletid "
                     "WHERE wh.playerid = %s ORDER BY t.transactiondate DESC, t.transactionid DESC;",
                     (player_id,))

    @staticmethod
    def get_player_reviews(player_id):
        return _rows("SELECT r.reviewid, r.walletid, w.wallettype, r.rating, r.reviewtext, r.reviewdate, "
                     "r.isverified FROM walletreviews r JOIN wallets w ON w.walletid = r.walletid "
                     "WHERE r.playerid = %s ORDER BY r.reviewdate DESC, r.reviewid DESC;", (player_id,))

    # ================================================================ transactions
    @staticmethod
    def get_wallet_transactions(wallet_id, date_from=None, date_to=None, txn_type=None):
        return _rows(
            "SELECT transactionid, walletid, transactiondate, amount, transactiontype, recipient, "
            "paymentmethod, linkedtxnid FROM gametransactions WHERE walletid = %s "
            "AND (%s::date IS NULL OR transactiondate >= %s::date) "
            "AND (%s::date IS NULL OR transactiondate <= %s::date) "
            "AND (%s::text IS NULL OR transactiontype = %s::text) "
            "ORDER BY transactiondate DESC, transactionid DESC;",
            (wallet_id, date_from, date_from, date_to, date_to, txn_type, txn_type))

    @staticmethod
    def totals_by_payment_method(wallet_id=None, player_id=None):
        return _rows(
            "SELECT paymentmethod, COUNT(*) AS txn_count, "
            "SUM(amount) FILTER (WHERE amount > 0) AS total_in, "
            "-SUM(amount) FILTER (WHERE amount < 0) AS total_out, "
            "SUM(ABS(amount)) AS total_volume FROM gametransactions "
            "WHERE (%s::int IS NULL OR walletid = %s::int) "
            "AND (%s::int IS NULL OR walletid IN (SELECT walletid FROM walletholders WHERE playerid = %s::int)) "
            "GROUP BY paymentmethod ORDER BY total_volume DESC;",
            (wallet_id, wallet_id, player_id, player_id))

    @staticmethod
    def reverse_transaction(transaction_id):
        """Admin only. Inserts offsetting 'Reversal' rows (both legs for a transfer);
        the trigger restores the balance. Returns the new transaction ids."""
        try:
            conn = DatabaseManager.get_connection()
            with conn:
                with conn.cursor() as cur:
                    cur.execute("SELECT transactiontype, linkedtxnid FROM gametransactions "
                                "WHERE transactionid = %s;", (transaction_id,))
                    row = cur.fetchone()
                    if not row:
                        conn.rollback()
                        return False, f"Transaction {transaction_id} does not exist."
                    ttype, linked = row
                    if ttype == "Reversal":
                        conn.rollback()
                        return False, "A reversal cannot itself be reversed."
                    ids = [transaction_id] + ([linked] if ttype == "Transfer" and linked else [])
                    cur.execute("SELECT 1 FROM gametransactions WHERE transactiontype = 'Reversal' "
                                "AND linkedtxnid = ANY(%s);", (ids,))
                    if cur.fetchone():
                        conn.rollback()
                        return False, f"Transaction {transaction_id} has already been reversed."
                    new_ids = []
                    for tid in ids:
                        cur.execute(
                            "INSERT INTO gametransactions (walletid, transactiondate, amount, transactiontype, "
                            "recipient, paymentmethod, linkedtxnid) "
                            "SELECT walletid, CURRENT_DATE, -amount, 'Reversal', 'Reversal of #' || transactionid, "
                            "paymentmethod, transactionid FROM gametransactions WHERE transactionid = %s "
                            "RETURNING transactionid;", (tid,))
                        new_ids.append(cur.fetchone()[0])
            return True, new_ids
        except Exception as e:
            from db.db_manager import friendly_error
            return False, friendly_error(e)

    @staticmethod
    def monthly_flows(wallet_id=None, player_id=None):
        """Monthly top-ups vs cash-outs + purchases (Optional Task 4, option 2)."""
        return _rows(
            "SELECT to_char(date_trunc('month', transactiondate), 'YYYY-MM') AS month, "
            "COALESCE(SUM(amount) FILTER (WHERE transactiontype = 'TopUp'), 0) AS topups, "
            "COALESCE(-SUM(amount) FILTER (WHERE transactiontype = 'Cashout'), 0) AS cashouts, "
            "COALESCE(-SUM(amount) FILTER (WHERE transactiontype = 'Purchase'), 0) AS purchases "
            "FROM gametransactions WHERE (%s::int IS NULL OR walletid = %s::int) "
            "AND (%s::int IS NULL OR walletid IN (SELECT walletid FROM walletholders WHERE playerid = %s::int)) "
            "GROUP BY 1 ORDER BY 1;", (wallet_id, wallet_id, player_id, player_id))

    # ================================================================ reviews
    @staticmethod
    def submit_wallet_review(player_id, wallet_id, rating, comment=None):
        """One review per player per wallet is enforced by uq_review_player_wallet."""
        ok, row = _one("INSERT INTO walletreviews (playerid, walletid, rating, reviewtext, reviewdate, isverified) "
                       "VALUES (%s, %s, %s, %s, CURRENT_DATE, FALSE) RETURNING reviewid;",
                       (player_id, wallet_id, rating, comment))
        return (True, row["reviewid"]) if ok else (False, row)

    @staticmethod
    def get_reviews(wallet_id=None):
        return _rows("SELECT r.reviewid, r.walletid, w.wallettype, r.playerid, "
                     "p.firstname || ' ' || p.lastname AS player, r.rating, r.reviewtext, "
                     "r.reviewdate, r.isverified FROM walletreviews r "
                     "JOIN wallets w ON w.walletid = r.walletid JOIN players p ON p.playerid = r.playerid "
                     "WHERE (%s::int IS NULL OR r.walletid = %s::int) "
                     "ORDER BY r.reviewdate DESC, r.reviewid DESC;", (wallet_id, wallet_id))

    @staticmethod
    def set_review_verified(review_id, verified):
        ok, row = _one("UPDATE walletreviews SET isverified = %s WHERE reviewid = %s RETURNING reviewid;",
                       (bool(verified), review_id), not_found="Review not found.")
        return (True, row["reviewid"]) if ok else (False, row)

    @staticmethod
    def get_average_rating_per_wallet_type():
        return _rows("SELECT w.wallettype, COUNT(r.reviewid) AS review_count, "
                     "ROUND(AVG(r.rating), 2) AS avg_rating FROM wallets w "
                     "LEFT JOIN walletreviews r ON r.walletid = w.walletid "
                     "GROUP BY w.wallettype ORDER BY w.wallettype;")
