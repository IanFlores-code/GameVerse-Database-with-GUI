"""Lets `pytest` (run from the repository root) import both the backend packages
(config/, db/, services/) and the GUI package (GameVerse_frontend/gameverse-app/gui)."""
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
for p in (ROOT, ROOT / "GameVerse_frontend" / "gameverse-app"):
    if str(p) not in sys.path:
        sys.path.insert(0, str(p))
